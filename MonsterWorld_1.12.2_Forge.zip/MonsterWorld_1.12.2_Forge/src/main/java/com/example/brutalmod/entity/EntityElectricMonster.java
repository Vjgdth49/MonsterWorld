package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityElectricMonster extends EntityMonsterBase {
 public EntityElectricMonster(World world){super(world);}
 @Override protected double health(){return 38D;} @Override protected double speed(){return .30D;} @Override protected double damage(){return 7D;} @Override protected double armor(){return 2D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
