package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityPoisonMonster extends EntityMonsterBase {
 public EntityPoisonMonster(World world){super(world);}
 @Override protected double health(){return 35D;} @Override protected double speed(){return .32D;} @Override protected double damage(){return 6D;} @Override protected double armor(){return 2D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
