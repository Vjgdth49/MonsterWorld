package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityBrutalMonster extends EntityMonsterBase {
 public EntityBrutalMonster(World world){super(world);}
 @Override protected double health(){return 45D;} @Override protected double speed(){return .30D;} @Override protected double damage(){return 8D;} @Override protected double armor(){return 5D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
