package com.example.brutalmod.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class EntityMonsterBase extends EntityMob {
    protected int specialCooldown;
    public EntityMonsterBase(World world) { super(world); this.setSize(1.0F, 2.0F); this.experienceValue = 12; }
    protected double health(){return 30;} protected double speed(){return .28;} protected double damage(){return 6;} protected double armor(){return 2;}
    @Override protected void applyEntityAttributes(){super.applyEntityAttributes(); getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(health()); getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(speed()); getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(damage()); getEntityAttribute(SharedMonsterAttributes.ARMOR).setBaseValue(armor()); getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32);}
    @Override protected void initEntityAI(){tasks.addTask(0,new EntityAISwimming(this)); tasks.addTask(2,new EntityAIAttackMelee(this,1.15D,false)); targetTasks.addTask(1,new EntityAIHurtByTarget(this,true)); targetTasks.addTask(2,new EntityAINearestAttackableTarget<EntityPlayer>(this,EntityPlayer.class,true));}
    @Override public void onLivingUpdate(){super.onLivingUpdate(); if(world.isRemote){for(int i=0;i<2;i++) world.spawnParticle(EnumParticleTypes.REDSTONE,posX+(rand.nextDouble()-.5)*width,posY+rand.nextDouble()*height,posZ+(rand.nextDouble()-.5)*width,1,0,0);} if(specialCooldown>0)specialCooldown--; EntityPlayer p=getAttackTarget() instanceof EntityPlayer?(EntityPlayer)getAttackTarget():null; if(!world.isRemote&&p!=null&&specialCooldown==0&&getDistance(p)<4&&canEntityBeSeen(p)){special(p);specialCooldown=80;}}
    protected void special(EntityPlayer p){p.attackEntityFrom(DamageSource.causeMobDamage(this),3); p.motionY+=.25;}
}
