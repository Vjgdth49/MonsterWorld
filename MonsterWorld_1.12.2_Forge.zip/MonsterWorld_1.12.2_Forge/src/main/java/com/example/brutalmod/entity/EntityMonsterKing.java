package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityMonsterKing extends EntityMonsterBase {
 public EntityMonsterKing(World world){super(world);}
 @Override protected double health(){return 180D;} @Override protected double speed(){return .25D;} @Override protected double damage(){return 16D;} @Override protected double armor(){return 12D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
