package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityShadowMonster extends EntityMonsterBase {
 public EntityShadowMonster(World world){super(world);}
 @Override protected double health(){return 25D;} @Override protected double speed(){return .42D;} @Override protected double damage(){return 9D;} @Override protected double armor(){return 1D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
