package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityHunterMonster extends EntityMonsterBase {
 public EntityHunterMonster(World world){super(world);}
 @Override protected double health(){return 28D;} @Override protected double speed(){return .38D;} @Override protected double damage(){return 6D;} @Override protected double armor(){return 1D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
