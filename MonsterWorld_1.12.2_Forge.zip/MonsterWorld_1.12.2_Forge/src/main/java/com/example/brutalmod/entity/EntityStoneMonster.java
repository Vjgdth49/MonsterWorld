package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityStoneMonster extends EntityMonsterBase {
 public EntityStoneMonster(World world){super(world);}
 @Override protected double health(){return 70D;} @Override protected double speed(){return .18D;} @Override protected double damage(){return 12D;} @Override protected double armor(){return 10D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
