package com.example.brutalmod.client.model;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
public class ModelMonster extends ModelBase {
 public ModelRenderer body,head,leftArm,rightArm,leftLeg,rightLeg,hornL,hornR;
 public ModelMonster(){body=new ModelRenderer(this,0,0); body.addBox(-5,0,-3,10,12,6); body.setRotationPoint(0,8,0); head=new ModelRenderer(this,0,18); head.addBox(-5,-5,-5,10,10,10); head.setRotationPoint(0,5,-1); leftArm=new ModelRenderer(this,40,0); leftArm.addBox(-2,0,-2,4,12,4); leftArm.setRotationPoint(7,9,0); rightArm=new ModelRenderer(this,40,0); rightArm.addBox(-2,0,-2,4,12,4); rightArm.setRotationPoint(-7,9,0); leftLeg=new ModelRenderer(this,56,0); leftLeg.addBox(-2,0,-2,4,10,4); leftLeg.setRotationPoint(3,20,0); rightLeg=new ModelRenderer(this,56,0); rightLeg.addBox(-2,0,-2,4,10,4); rightLeg.setRotationPoint(-3,20,0); hornL=new ModelRenderer(this,0,40); hornL.addBox(-1,-5,-1,2,5,2); hornL.setRotationPoint(4,0,-1); hornR=new ModelRenderer(this,0,40); hornR.addBox(-1,-5,-1,2,5,2); hornR.setRotationPoint(-4,0,-1); }
 public void render(Entity e,float a,float b,float c,float d,float f,float s){body.render(s);head.render(s);leftArm.render(s);rightArm.render(s);leftLeg.render(s);rightLeg.render(s);hornL.render(s);hornR.render(s);}
}
