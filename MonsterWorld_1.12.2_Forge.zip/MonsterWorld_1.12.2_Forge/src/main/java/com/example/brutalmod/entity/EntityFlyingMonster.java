package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityFlyingMonster extends EntityMonsterBase {
 public EntityFlyingMonster(World world){super(world);}
 @Override protected double health(){return 32D;} @Override protected double speed(){return .34D;} @Override protected double damage(){return 5D;} @Override protected double armor(){return 2D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
