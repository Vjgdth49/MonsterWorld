package com.example.brutalmod.client.render;
import com.example.brutalmod.client.model.ModelMonster;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;
import com.example.brutalmod.BrutalMod;
public class RenderMonster<T extends EntityLiving> extends RenderLiving<T>{
 private static final ResourceLocation TEX=new ResourceLocation(BrutalMod.MODID,"textures/entity/monster.png");
 public RenderMonster(RenderManager m){super(m,new ModelMonster(),.6f);}
 @Override protected ResourceLocation getEntityTexture(T e){return TEX;}
}
