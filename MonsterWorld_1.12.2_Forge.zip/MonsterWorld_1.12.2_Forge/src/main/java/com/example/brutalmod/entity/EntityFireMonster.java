package com.example.brutalmod.entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
public class EntityFireMonster extends EntityMonsterBase {
 public EntityFireMonster(World world){super(world);}
 @Override protected double health(){return 40D;} @Override protected double speed(){return .28D;} @Override protected double damage(){return 7D;} @Override protected double armor(){return 3D;}
 @Override protected void special(EntityPlayer p){super.special(p);}
}
