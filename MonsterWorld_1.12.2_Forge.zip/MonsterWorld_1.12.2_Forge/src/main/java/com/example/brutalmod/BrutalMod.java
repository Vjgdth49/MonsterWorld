package com.example.brutalmod;

import com.example.brutalmod.entity.*;
import com.example.brutalmod.client.render.RenderMonster;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.registry.EntityRegistry;

@Mod(modid=BrutalMod.MODID,name=BrutalMod.NAME,version=BrutalMod.VERSION)
public class BrutalMod {
 public static final String MODID="brutalmod", NAME="Monster World", VERSION="2.0";
 @Mod.EventHandler public void preInit(FMLPreInitializationEvent e){
  register(EntityBrutalMonster.class,"brutal_monster",1,0x111111,0xFFCC00);
  register(EntityFireMonster.class,"fire_monster",2,0x111111,0xFF3300);
  register(EntityPoisonMonster.class,"poison_monster",3,0x111111,0x55FF00);
  register(EntityElectricMonster.class,"electric_monster",4,0x111111,0xFFFF00);
  register(EntityStoneMonster.class,"stone_monster",5,0x555555,0xAA0000);
  register(EntityHunterMonster.class,"hunter_monster",6,0x111111,0xFFCC00);
  register(EntityFlyingMonster.class,"flying_monster",7,0x111111,0xFFFF00);
  register(EntityShadowMonster.class,"shadow_monster",8,0x050505,0x9900FF);
  register(EntityMonsterKing.class,"monster_king",9,0x111111,0xFFCC00);
 }
 private <T extends net.minecraft.entity.Entity> void register(Class<T> c,String id,int numericId,int egg1,int egg2){EntityRegistry.registerModEntity(new ResourceLocation(MODID,id),c,id,numericId,this,80,3,true,egg1,egg2);}
 @Mod.EventHandler public void init(net.minecraftforge.fml.common.event.FMLInitializationEvent e){
  if(e.getSide().isClient()){RenderingRegistry.registerEntityRenderingHandler(EntityBrutalMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityFireMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityPoisonMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityElectricMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityStoneMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityHunterMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityFlyingMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityShadowMonster.class,RenderMonster::new);RenderingRegistry.registerEntityRenderingHandler(EntityMonsterKing.class,RenderMonster::new);}
 }
}
