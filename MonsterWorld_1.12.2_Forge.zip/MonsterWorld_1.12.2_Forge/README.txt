MONSTER WORLD - Minecraft 1.12.2 Forge
======================================

Project for Forge 1.12.2 (14.23.5.2860), Java 8.
Contains 9 monster entities: Brutal, Fire, Poison, Electric, Stone, Hunter, Flying, Shadow, Monster King.

BUILD:
1. Install Java 8.
2. In this project folder run: gradlew setupDecompWorkspace
3. Then: gradlew build
4. The JAR will appear in build/libs/.

POJAVLAUNCHER:
Install Forge 1.12.2 first, then copy the resulting .jar into the mods folder for that Forge profile.

NOTE: This is a source project. Textures/model are intentionally simple so you can replace them later.
